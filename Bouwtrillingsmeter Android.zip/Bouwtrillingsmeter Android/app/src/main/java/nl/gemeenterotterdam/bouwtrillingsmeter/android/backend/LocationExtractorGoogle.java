package nl.gemeenterotterdam.bouwtrillingsmeter.android.backend;

/**
 * Uses the Google location API to extract
 * the location of the device.
 */
public class LocationExtractorGoogle {



}
