package nl.gemeenterotterdam.bouwtrillingsmeter.android.frontend;

public enum Dimension {
    X,
    Y,
    Z
}
