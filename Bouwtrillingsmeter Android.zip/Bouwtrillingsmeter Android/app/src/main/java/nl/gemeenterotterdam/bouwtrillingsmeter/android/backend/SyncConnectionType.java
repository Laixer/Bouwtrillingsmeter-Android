package nl.gemeenterotterdam.bouwtrillingsmeter.android.backend;

/**
 * Connection type enum
 */
enum SyncConnectionType {
    NONE,
    WIFI,
    WIFI_AND_G,
    G
}