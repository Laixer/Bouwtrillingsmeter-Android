# Bouwtrillingsmeter-Android
Bouwtrillingsmeter voor Android.
De repo van de eerste app die gemaakt is voor Android, en nu op de appstore staat, is hernoemd tot "Bouwtrillingsmeter-Android-Old".

Deze repo is gemaakt from scratch, volgens de gewenste eigenschappen en style guidelines.
Enkel code van de oude repo die het harde rekenwerktdoet wordt herbruikt.
